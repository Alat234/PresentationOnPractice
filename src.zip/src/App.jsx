import PresentationLayout from './components/layout/PresentationLayout'
import Slide01Title from './slides/Slide01Title'
import Slide02PracticeOverview from './slides/Slide02PracticeOverview'
import Slide03AppliedKnowledge from './slides/Slide03AppliedKnowledge'
import Slide04ProjectGoal from './slides/Slide04ProjectGoal'
import SlidePlaceholder from './slides/SlidePlaceholder'
import { slidesMeta } from './data/slides'
import './styles/reset.css'
import './styles/tokens.css'
import './styles/layout.css'
import './styles/components.css'
import './styles/slides.css'

const slideComponents = [
    Slide01Title,
    Slide02PracticeOverview,
    Slide03AppliedKnowledge,
    Slide04ProjectGoal,
    () => <SlidePlaceholder number="05" label={slidesMeta[4].label} title={slidesMeta[4].title} />,
    () => <SlidePlaceholder number="06" label={slidesMeta[5].label} title={slidesMeta[5].title} />,
    () => <SlidePlaceholder number="07" label={slidesMeta[6].label} title={slidesMeta[6].title} />,
    () => <SlidePlaceholder number="08" label={slidesMeta[7].label} title={slidesMeta[7].title} />,
    () => <SlidePlaceholder number="09" label={slidesMeta[8].label} title={slidesMeta[8].title} />,
    () => <SlidePlaceholder number="10" label={slidesMeta[9].label} title={slidesMeta[9].title} />,
]

function App() {
    return <PresentationLayout slidesMeta={slidesMeta} slideComponents={slideComponents} />
}

export default App