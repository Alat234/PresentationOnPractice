import Accordion from '../components/ui/Accordion'
import InfoCard from '../components/ui/InfoCard'
import SectionLabel from '../components/ui/SectionLabel'
import practiceTimeline from '../data/practiceTimeline'
import '../styles/slides/slide02-practice-overview.css'

const summaryCards = [
    {
        title: 'Формат',
        value: 'Послідовне модульне навчання',
        description:
            'Програма була побудована як покроковий перехід від базових тем Java до Spring web development.',
    },
    {
        title: 'Тривалість',
        value: '6+ тижнів',
        description:
            'Кожен етап мав окремий тематичний фокус: fundamentals, design, database/web, Spring, final project.',
    },
    {
        title: 'Результат',
        value: 'База для фінального проєкту',
        description:
            'На виході було сформовано набір знань і практичних навичок, які далі застосувалися у власному проєкті.',
    },
]

function Slide02PracticeOverview() {
    return (
        <article className="slide slide--practice-overview">
            <SectionLabel>Практика в EPAM</SectionLabel>

            <header className="slide__intro">
                <h1 className="slide__title">Структура програми</h1>
                <p className="slide__text slide__text--wide">
                    Java Fundamentals Program охоплювала послідовний перехід від базових
                    тем Java до web development with Spring.
                </p>
            </header>

            <section className="practice-summary-grid">
                {summaryCards.map((item) => (
                    <InfoCard
                        key={item.title}
                        title={item.title}
                        value={item.value}
                        description={item.description}
                    />
                ))}
            </section>

            <section className="practice-overview-section">
                <div className="section-heading">
                    <h2 className="section-heading__title">Етапи проходження</h2>
                    <p className="section-heading__text">
                        Нижче подано структуру програми по тижнях. Кожен етап можна
                        розгорнути та переглянути модулі й ключові теми.
                    </p>
                </div>

                <div className="practice-overview__accordion-list">
                    {practiceTimeline.map((item, index) => (
                        <Accordion
                            key={item.week}
                            eyebrow={item.week}
                            title={item.title}
                            defaultOpen={index === 0}
                        >
                            <div className="practice-stage">
                                <p className="practice-stage__description">{item.description}</p>

                                <div className="practice-stage__grid">
                                    <div className="practice-stage__block">
                                        <h4 className="practice-stage__subtitle">Модулі та теми</h4>
                                        <ul className="accordion__list">
                                            {item.modules.map((module) => (
                                                <li key={module} className="accordion__list-item">
                                                    {module}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>

                                    <div className="practice-stage__block">
                                        <h4 className="practice-stage__subtitle">Підсумок етапу</h4>
                                        <p className="practice-stage__result">{item.result}</p>
                                    </div>
                                </div>
                            </div>
                        </Accordion>
                    ))}
                </div>
            </section>
        </article>
    )
}

export default Slide02PracticeOverview